;**************************************************************************
; MICROPROCESSOR-BASED SYSTEMS
; LAB SESSION 1
; FILE: labs1c.asm
; AUTHORS: Emilio Cuesta Fernandez - Alejandro Sanchez Sanz
; COUPLE NUMBER: 8
; GROUP: 2351
;**************************************************************************

It is really important to read the comment in the bottom of the labs1c.asm file.
