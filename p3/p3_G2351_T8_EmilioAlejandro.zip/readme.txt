AUTHORS: Emilio Cuesta Fernandez, Alejandro Sanchez Sanz 
TEAM 8
GROUP 2351

We have modified pract3.c adding these functionalities:
    * The attempt will be printed once it has been accepted, in order to check if it has been filled correctly.
    * The attempt can't have repeated digits (because it would not make sense in a real game), so we check that in do...while condition.
      Even though, this wont be considered as a failed attempt.

